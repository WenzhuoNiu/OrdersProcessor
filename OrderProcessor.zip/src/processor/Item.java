package processor;

public class Item {
	private String name;
	private double cost;
	
	public Item(String name, double price) {
		this.name = name;
		this.cost = price;
	}
	
	public String getName() {
		return name;
	}
	
	public double getCost() {
		return cost;
	}
}
