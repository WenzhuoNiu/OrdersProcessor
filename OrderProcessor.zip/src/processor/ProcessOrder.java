package processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map.Entry;

public class ProcessOrder implements Runnable {
	private Client order;
	private TreeMap<String, Integer> itemsCount;
	private Income totalIncome;
	private String fileName;
	private ArrayList<Item> items;
	private String resultFileName;
	private File resultFile;
	private FileWriter fw;
	private BufferedWriter bw;
	private TreeMap<Integer, String> bills;

	public ProcessOrder(Client order, TreeMap<String, Integer> itemsCount, Income totalIncome, String fileName,
			ArrayList<Item> items, String resultFileName, FileWriter fw, BufferedWriter bw, File resultFile,
			TreeMap<Integer, String> bills) {
		this.order = order;
		this.itemsCount = itemsCount;
		this.totalIncome = totalIncome;
		this.fileName = fileName;
		this.items = items;
		this.resultFileName = resultFileName;
		this.resultFile = resultFile;
		this.bw = bw;
		this.fw = fw;
		this.bills = bills;
	}

	@Override
	public void run() {
		DecimalFormat df = new DecimalFormat("###,###,##0. 00");
		int clientId = 0;
		Scanner scanner = null;
		try {
			scanner = new Scanner(new File(fileName));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		while (scanner.hasNext()) {
			scanner.next();
			clientId = scanner.nextInt();
			System.out.println("Reading order for client with id: " + clientId);
			order = new Client(clientId);
			scanner.nextLine();
			while (scanner.hasNext()) {
				String item = scanner.next();
				order.addItem(item);

				synchronized (itemsCount) {
					Integer num = itemsCount.get(item);
					if (num == null) {
						itemsCount.put(item, 1);
					} else {
						itemsCount.put(item, num + 1);
					}
				}
				scanner.nextLine();
			}
		}
		scanner.close();

		String bill = "----- Order details for client with Id: " + order.getId() + " -----" + "\n";
		double totalOrder = 0.0;

		for (Entry<String, Integer> it : order.getItems().entrySet()) {

			String name = it.getKey();
			double cost = 0.0;
			for (Item item : items) {
				if (name.equals(item.getName())) {
					cost = item.getCost();
					break;
				}
			}


			bill += "Item's name: " + name + ", " + "Cost per item:" + "$" + df.format(cost) + ", " + "Quantity: "
					+ order.getItems().get(name) + ", " + "Cost: $" + df.format(cost * order.getItems().get(name))
					+ "\n";
			totalOrder += (cost * order.getItems().get(name));
		}
		bill += "Order Total: $" + df.format(totalOrder) + "\n";

		synchronized (bills) {
			bills.put(clientId, bill);
		}
		synchronized (totalIncome) {
			totalIncome.add(totalOrder);
		}
	}
}
