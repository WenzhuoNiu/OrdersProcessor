package processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;




public class Client  implements Iterable<Item>{
	private int id;
	private TreeMap<String, Integer> items;

	public Client(int id) {
		this.id = id;
		items = new TreeMap<>();
	}

	public int getId() {
		return id;
	}
	
	public TreeMap<String, Integer> getItems(){
		return items;
	}

	public void addItem(String name) {
		if(!items.containsKey(name)) {
			items.put(name, 1);
			return;
		}
		items.put(name, items.get(name) + 1);
	}

	@Override
	public Iterator<Item> iterator() {
		return iterator();
	}

}
