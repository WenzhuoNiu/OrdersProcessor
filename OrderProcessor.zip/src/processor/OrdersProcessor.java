package processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class OrdersProcessor {

	public ArrayList<Item> readItems(String dataFile) throws FileNotFoundException {
		ArrayList<Item> items = new ArrayList<>();

		Scanner scanner2 = new Scanner(new File(dataFile));
		while (scanner2.hasNext()) {
			String name = scanner2.next();
			double price = scanner2.nextDouble();
			items.add(new Item(name, price));
			if (scanner2.hasNext()) {
				scanner2.nextLine();
			}
		}
		scanner2.close();
		return items;
	}

	public static void main(String[] args) throws FileNotFoundException, InterruptedException, IOException {
		DecimalFormat df = new DecimalFormat("###,###,##0. 00");
		OrdersProcessor op = new OrdersProcessor();
		FileWriter fileWriter = null;
		BufferedWriter bw = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter item's data file name:  ");
		String data = scanner.next();
		ArrayList<Item> items = op.readItems(data);

		System.out.println("Enter 'y' for multiple threads, any other character otherwise: ");
		String answer = scanner.next();

		System.out.println("Enter number of orders to process: ");
		int number = scanner.nextInt();

		System.out.println("Enter order's base filename: ");
		String base = scanner.next();

		System.out.println("Enter result's filename: ");
		String result = scanner.next();
		long startTime = System.currentTimeMillis();
		File resultFile = new File(result);
		fileWriter = new FileWriter(resultFile);
		bw = new BufferedWriter(fileWriter);

		TreeMap<String, Integer> itemsCount = new TreeMap<>();
		Income totalIncome = new Income(0);
		Client order = null;
	
		if (!answer.equals("y")) {
			for (int i = 1; i <= number; i++) {
				Scanner scanner3 = null;
				try {
					String baseFile = base + i + ".txt";
					scanner3 = new Scanner(new File(baseFile));
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}

				while (scanner3.hasNext()) {
					scanner3.next();
					int clientId = scanner3.nextInt();
					System.out.println("Reading order for client with id: " + clientId);
					order = new Client(clientId);
					scanner3.nextLine();
					while (scanner3.hasNext()) {
						String item = scanner3.next();
						order.addItem(item);

						synchronized (itemsCount) {
							Integer num = itemsCount.get(item);
							if (num == null) {
								itemsCount.put(item, 1);
							} else {
								itemsCount.put(item, num + 1);
							}
						}
						scanner3.nextLine();
					}
				}
				scanner3.close();

				String bill = "----- Order details for client with Id: " + order.getId() + " -----" + "\n";
				double totalOrder = 0.0;

				for (Entry<String, Integer> it : order.getItems().entrySet()) {

					String name = it.getKey();
					double cost = 0.0;
					for (Item item : items) {
						if (name.equals(item.getName())) {
							cost = item.getCost();
							break;
						}
					}

					bill += "Item's name: " + name + ", " + "Cost per item: " + "$" + df.format(cost) + ","
							+ "Quantity: " + order.getItems().get(name) + ", " + "Cost: $"
							+ df.format(cost * order.getItems().get(name)) + "\n";
					totalOrder += (cost * order.getItems().get(name));
				}

				bill += "Order Total: $" + df.format(totalOrder) + "\n";
				bw.write(bill);
				synchronized (totalIncome) {
					totalIncome.add(totalOrder);
				}
			}
		} else {
			ArrayList<Thread> allThreads = new ArrayList<>();
			TreeMap<Integer, String> bills = new TreeMap<>();
			for (int i = 1; i <= number; i++) {
				String baseFile = base + i + ".txt";
				allThreads.add(new Thread(new ProcessOrder(order, itemsCount, totalIncome, baseFile, items, result,
						fileWriter, bw, resultFile, bills)));
			}
			for (Thread t : allThreads) {
				t.start();
			}
			for (Thread t : allThreads) {
				t.join();
			}
			try {

				for (Entry<Integer, String> bi : bills.entrySet()) {
					bw.write(bi.getValue());

				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		bw.write("***** Summary of all orders *****" + "\n");
		for (Map.Entry<String, Integer> elem : itemsCount.entrySet()) {
			for (Item item : items) {
				if (item.getName().equals(elem.getKey())) {
					bw.write("Summary - " + "Item's name: " + elem.getKey() + ", " + "Cost per item: $"
							+ df.format(item.getCost()) + ", " + "Number sold: " + elem.getValue() + ", "
							+ "Item's Total: $" + df.format((elem.getValue()) * item.getCost()) + "\n");
				}
			}
		}
		String allCost = df.format(totalIncome.getValue());
		bw.write("Summary Grand Total: $" + allCost + "\n");
		bw.close();

		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		System.out.println("Results can be found in the file: " + result);

	}
}